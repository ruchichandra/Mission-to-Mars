# Twitter API Keys
consumer_key = "IBGGnfEVkiWyiy378JZUGTa7R"
consumer_secret = "kKLPE1KsUjyQAZyuo1RVFD3wncEZ7ByTJfxtAz32RkIibTpG0o"
access_token = "857769437113577472-F9b6yeB1bLZuWoTGDtLWftwHC6y307S"
access_token_secret = "m3K1meWntHu7V8koLPag4C5RCp64PgQXhBPOH2PjRDE0p"